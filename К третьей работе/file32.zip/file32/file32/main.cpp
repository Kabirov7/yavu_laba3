#include "pch.h"
#include "main.h"
DLL_EXPORT fstream* open(char* path, bool read)
{
    //const char* newpath = "rext.txt";
    //bool read = true;
    /*wstring your_wchar_in_ws(path);
        string your_wchar_in_str(your_wchar_in_ws.begin(), your_wchar_in_ws.end());
        const char* newpath =  your_wchar_in_str.c_str();
        */

//		cout<<1;
    
    fstream* file;
    if (read) {
        file = new fstream();
        	file->open(path,ios_base::in);
    }
    else
    {
        file = new fstream();
        	file->open(path,ios_base::out|ios_base::trunc);
    }
    string res;
    //getline(*file, res, ' ');
    //cout << your_wchar_in_str;
    //cout << res;
    	cout<<"open";
    return file;
    //return nullptr;
}

DLL_EXPORT void close(fstream* file)
{
    file->close();
    delete file;
};
DLL_EXPORT bool read(fstream* file, int num,char* word)
{
    file->clear();
    file->seekg(0);
    if (num<1 || num>length(file))
        return false;
    static string res;
    int i = 0;
    while (i < num)
    {
        getline(*file, res, ' ');
        i++;
    }
    strcpy_s(word, 255,res.c_str());
    file->clear();
    file->seekg(0);
    return true;
};

DLL_EXPORT void write(fstream* file, char* text)
{
    file->clear();
    file->seekg(0);
    file->write(text,strlen(text));
}

DLL_EXPORT int length(fstream* file)
{
    int res = 0;
    string tmp;
    while (!file->eof())
    {
        getline(*file, tmp, ' ');
        res++;
    }
    file->clear();
    file->seekg(0);
    return res;
}